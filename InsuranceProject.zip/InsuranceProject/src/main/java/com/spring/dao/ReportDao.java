package com.spring.dao;

import java.util.List;

import com.spring.model.Report;

public interface ReportDao 
{
	public int addReport(Report r);
	public List<Report> getReports();
	public Report getReport(int id);
}
